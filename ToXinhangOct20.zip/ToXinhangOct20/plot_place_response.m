%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plot_place_resp.m
%
% Description:
% This script map the frequency-dependent cochlear response to a
% place-dependent one
%
%
% Author: Liming Wang
% Date: April 18
%
% Modification history:
%   April 21: 
%   Select the frequency equally spaced in octave scale rather than in
%   linear scale; 
%

%   April 22:
%   filter the signal using a double delta function (a crude high pass filter)
%   as the middle ear transfer function 
%   
%   June 6:
%   Add some switches and do some cleanup
%
%   July 2:
%   Delete debug and double delta code
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clf

% Initialize switches
PLOT_CAT = 1;
FILTER_DD = 0;
CLOSEST_LINEAR = 0; % Pick the closest freq index in linear scale or log scale
DEBUG = 0;

addpath(genpath('bin/'))
load('default_200chan.mat', 'P', 'S')
% Load the Chris's cochlea response, copy relevant parameters to local
% space
N = S.N; % number of frequency; also the number of time frames
M = S.M; % number of place channels
L = S.L; % number of stiffness
H = S.H;
Fs = 75000;
L_coch = 35;
x = S.x;
f = S.f;
nsel_s = 1;
nsel_f = 8;

fig_num = 1;

ssel = [20]; %round(linspace(1, L, nsel_s));


% Plot the cochlea map
fmax = max(f);
figure(fig_num)
fig_num = fig_num + 1;
fx = empx2f(S.x2f, x);
plot(L_coch*(1-x), log(fx)/log(2))
xlabel('Place [mm]')
ylabel('CF [octave]')
col = reshape(grad_cmap(nsel_f*nsel_s), [nsel_f, nsel_s, 3]);

% Plot the TM filter
TM_filter = 0.25*10.^(3/2*(0.6-(1-x))+1/10);

figure(fig_num)
plot(L_coch*(1-x), TM_filter)
xlabel('Distance from stapes [mm]')
ylabel('Magnitude [dB]')
title('TM filter place response')

% plot the place responses on the same figure
figure(fig_num)
fig_num = fig_num + 1;
% Select the place responses from filter responses; 
% place corresponds to octave scale in frequency
fstart = 250;
fval = zeros(1, nsel_f);
Hsel = zeros(nsel_f, M, L); 

for k = 1:nsel_f
    fcur = fstart*2^(k-1);
    if CLOSEST_LINEAR
        [~, minidx] = min(abs(fcur-f));
    else
        % Use log scale instead to get the frequency index 
        [~, minidx] = min(abs(log(f)-log(fcur)));
    fval(k) = f(minidx);
    Hsel(k, :, :) =  H(minidx, :, :); 
    end
end

kernel = ones(M, 1);
for j = 1:nsel_f
    for k = 1:length(ssel)
       Hp = squeeze(Hsel(j, :, ssel(k))).*TM_filter;
       plot(L_coch*(1-x), 20*log10(abs(Hp)+eps), 'Color', squeeze(col(j, k, :)), 'Linestyle', '-');
       hold on
    end
end
hold off
xlabel('Distance from stapes [mm]')
ylabel('Magnitude [dB]')
title('Place response of cochlea')
ylim([-80, 0])
print('NLC_coch_place', '-deps')
pretty;

% Plot the phases
figure(fig_num)
fig_num = fig_num + 1;
for j = 1:nsel_f
    for k = 1:length(ssel)
       Hp = squeeze(Hsel(j, :, k));
       plot(L_coch*(1-x), angle(Hp), 'Color', squeeze(col(j, k, :)));
       hold on
    end
end
xlabel('Distance from apex [mm]')
ylabel('Phase [rad]')
title('Phase of the place response of cochlea')
