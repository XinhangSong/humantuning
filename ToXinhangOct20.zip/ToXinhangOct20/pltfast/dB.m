%o=dB(x)
% convert from linear (volts) to db
function o=dB(x)
o=20*log10(x)
