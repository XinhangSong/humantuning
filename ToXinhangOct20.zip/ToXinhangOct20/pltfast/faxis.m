function f=faxis(fmax,nfft)
nf=nfft/2+1;
fmin=fmax/(nf-1);
f=fmin.*(0:nf-1);
