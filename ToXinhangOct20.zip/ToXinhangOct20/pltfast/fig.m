function [h]=fig(i);
h=figure(i);
%set(h,'Position',[001 524 560 420])
set(h,'Position',[001+(i-1)*20 430-(i-1)*22 700 520]);
