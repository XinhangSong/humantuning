function pltgast(X,fmax,s2)
	if nargin==3,
color=s2;
	else
color='w'
	end
nf=length(X);
nft=2*(nf-1);
f=faxis(fmax,nft); f=f(:);
fee=angle(X);
fee=unwrap(fee); fee=fee(:);
gd=diff(fee) ./ diff(f);
gd=-1e3*gd/(2*pi);
semilogx(f(2:nf-1),gd(2:nf-1),color);xlabel('freq');ylabel('group dly- ms')
axis([f(2),fmax,0.,2.]);
axis;
