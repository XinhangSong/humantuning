% Plot the results of X=fast(x)
% Usage:
%	 pltfast(X)
%	 pltfast(X,fmax)
%
% Usage with graphics string control:
%	 pltfast(X,':g')
%	 pltfast(X,fmax,'g+')

function pltfast(X,s1,s2, varargin)

nf=length(X);
nft=2*(nf-1);
string='k';
fmax=25000;

if nargin == 1,
%fmax=25000;
%string='g'

elseif nargin == 2,
	if isstr(s1),
string=s1;
%fmax=25000 
fmax=s1;
%string='g'
    end

elseif nargin==3,
fmax=s1;
string=s2;
else,
% By Liming Wang, Oct 9 2017
fmax=s1;
string=s2;
fmarker=varargin{1};
%echo '1 to 3 arguments'
end

f=faxis(fmax,nft);
i=1+find(abs(X(2:nf-1))~=0); %remove bad points

% Edit by Liming Wang, Oct 9 2017
imarker = find(f(i) <= fmarker);
%disp(imarker)
loglog(f(i),abs(X(i)),string,'Marker', 'o', 'MarkerEdgeColor', 'b', 'MarkerIndices', imarker(end))
line([f(imarker(end)); f(imarker(end))],[10^(-4), abs(X(imarker(end)))],'Color','b','LineWidth',1,'LineStyle','--')
xlabel('FREQUENCY (Hz)');ylabel('MAGNITUDE')