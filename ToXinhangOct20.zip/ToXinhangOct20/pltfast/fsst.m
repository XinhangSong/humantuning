function y = fsst(x,nfft)
%FASTIFFT	Inverse discrete Fourier transform (Complex to real).
%	fsst(X) is the inverse discrete Fourier transform of vector X which
%              is known to be symmetric so that the result has to be real. 
%	fsst(X,N) is the corresponding N-point inverse transform.

%	See also FAST()
%	G. Kubin 08-28-92, Jont Allen 9-25-92

[k,l]=size(x);
	if l > k
nf=l;
% zero out Imag part in DC and Fmax
x(:,1)=real(x(:,1));
x(:,nf)=real(x(:,nf));
y=[x,conj(x(nf-1:-1:2))];

	else
nf=k;
% zero out Imag part in DC and Fmax
x(1,:)=real(x(1,:));
x(nf,:)=real(x(nf,:));
y=[x;conj(x(nf-1:-1:2))];
	end

y = real(y) + imag(y);

if nargin == 2
    y = fft(y,nfft);
else
    y = fft(y);
end
y = real(y) + imag(y);
[m,n] = size(y);
if m == 1
    m = n;
end
y = y/m;
