%FAST: FFT that returns only the positive frequencies
% Usage:    S=fast(s);
% If s is N points long, NF=N/2+1 complex points are returned.
%Normalization:
% and X = fft(x)
% then norm(x) = sqrt[(x,x)] = ||x|| = ||X||/sqrt(N)
% and RMS(x) = ||x||/sqrt(N) = ||X||/N = std(x) = sigma_x 
% Let  X~ = fast(x)
% then RMS(x) = ||[X~,X~(2:(NF-1))]||/N
 
function X=fast(x)
n=length(x)/2+1;
xc=fft(x);
X=xc(1:fix(n));
